import streamlit as st

st.set_page_config(
    page_title="🏏 Cricbuzz LiveStats",
    page_icon="🏏",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("Welcome to Cricbuzz LiveStats! 🏏")
st.markdown("---")
st.write("""
    **Cricbuzz LiveStats** — Your one-stop dashboard for real-time cricket insights, player statistics,
    SQL-based analytics, and player data management.

    Navigate through the different sections using the sidebar on the left to explore various features.
""")
st.info("👈 Select a page from the sidebar to begin your cricket data exploration!")