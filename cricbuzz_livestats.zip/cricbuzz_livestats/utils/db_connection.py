import mysql.connector
from mysql.connector import Error
import streamlit as st # Added streamlit for error messages, will show them in the app.

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "Anita@086",  # <--- !!! APNA MYSQL PASSWORD YAHAN DAALNA !!!
    "database": "cricbuzz_db"
}

def get_connection():
    """Create and return a MySQL database connection."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Error as e:
        # st.error is used here so errors show up in the Streamlit app.
        st.error(f"❌ Database Connection Error: {e}. Please ensure your MySQL server is running and "
                 f"credentials are correct in `utils/db_connection.py`.")
        return None

def execute_query(query, params=None, fetch=True):
    """Execute a SQL query and optionally fetch results."""
    conn = get_connection()
    if conn is None:
        return None # Error already reported by get_connection()
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        if fetch:
            result = cursor.fetchall()
            return result
        else:
            conn.commit()
            return cursor.rowcount # Return affected rows for non-SELECT queries
    except Error as e:
        st.error(f"❌ SQL Query Error: {e}. Query: `{query}`")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

def create_database_and_tables():
    """Create the database and all required tables."""
    try:
        conn = mysql.connector.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"]
        )
        cursor = conn.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS cricbuzz_db")
        cursor.execute("USE cricbuzz_db")

        # Players table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS players (
                player_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                full_name VARCHAR(200),
                country VARCHAR(50),
                playing_role VARCHAR(50),
                batting_style VARCHAR(50),
                bowling_style VARCHAR(100),
                date_of_birth DATE,
                image_url VARCHAR(500),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        """)

        # Teams table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS teams (
                team_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                short_name VARCHAR(10),
                country VARCHAR(50),
                image_url VARCHAR(500)
            )
        """)

        # Venues table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS venues (
                venue_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(200) NOT NULL,
                city VARCHAR(100),
                country VARCHAR(100),
                capacity INT DEFAULT 0
            )
        """)

        # Series table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS series (
                series_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(200) NOT NULL,
                host_country VARCHAR(100),
                match_type VARCHAR(20),
                start_date DATE,
                end_date DATE,
                total_matches INT DEFAULT 0
            )
        """)

        # Matches table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS matches (
                match_id INT AUTO_INCREMENT PRIMARY KEY,
                description VARCHAR(300),
                match_format VARCHAR(20),
                team1_id INT,
                team2_id INT,
                venue_id INT,
                series_id INT,
                match_date DATETIME,
                status VARCHAR(100),
                toss_winner_id INT,
                toss_decision VARCHAR(10),
                winner_id INT,
                victory_margin INT,
                victory_type VARCHAR(20),
                FOREIGN KEY (team1_id) REFERENCES teams(team_id),
                FOREIGN KEY (team2_id) REFERENCES teams(team_id),
                FOREIGN KEY (venue_id) REFERENCES venues(venue_id),
                FOREIGN KEY (series_id) REFERENCES series(series_id)
            )
        """)

        # Batting Stats table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS batting_stats (
                stat_id INT AUTO_INCREMENT PRIMARY KEY,
                player_id INT,
                match_id INT,
                innings INT,
                runs_scored INT DEFAULT 0,
                balls_faced INT DEFAULT 0,
                fours INT DEFAULT 0,
                sixes INT DEFAULT 0,
                strike_rate DECIMAL(6,2) DEFAULT 0.00,
                batting_position INT,
                is_not_out BOOLEAN DEFAULT FALSE,
                FOREIGN KEY (player_id) REFERENCES players(player_id),
                FOREIGN KEY (match_id) REFERENCES matches(match_id)
            )
        """)

        # Bowling Stats table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bowling_stats (
                stat_id INT AUTO_INCREMENT PRIMARY KEY,
                player_id INT,
                match_id INT,
                innings INT,
                overs_bowled DECIMAL(5,1) DEFAULT 0.0,
                runs_conceded INT DEFAULT 0,
                wickets_taken INT DEFAULT 0,
                maidens INT DEFAULT 0,
                economy_rate DECIMAL(5,2) DEFAULT 0.00,
                FOREIGN KEY (player_id) REFERENCES players(player_id),
                FOREIGN KEY (match_id) REFERENCES matches(match_id)
            )
        """)

        # Career Stats table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS career_stats (
                career_id INT AUTO_INCREMENT PRIMARY KEY,
                player_id INT,
                match_format VARCHAR(20),
                matches_played INT DEFAULT 0,
                total_runs INT DEFAULT 0,
                batting_average DECIMAL(6,2) DEFAULT 0.00,
                strike_rate DECIMAL(6,2) DEFAULT 0.00,
                centuries INT DEFAULT 0,
                half_centuries INT DEFAULT 0,
                highest_score INT DEFAULT 0,
                total_wickets INT DEFAULT 0,
                bowling_average DECIMAL(6,2) DEFAULT 0.00,
                bowling_economy DECIMAL(5,2) DEFAULT 0.00,
                catches INT DEFAULT 0,
                stumpings INT DEFAULT 0,
                bowling_strike_rate DECIMAL(6,2) DEFAULT 0.00, /* Added this for completeness */
                FOREIGN KEY (player_id) REFERENCES players(player_id)
            )
        """)

        conn.commit()
        print("Database and tables created successfully!")

    except Error as e:
        print(f"Error creating database or tables: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

def insert_sample_data():
    """Insert sample data into all tables for testing."""
    conn = get_connection()
    if conn is None:
        print("Skipping sample data insertion due to DB connection error.")
        return
    try:
        cursor = conn.cursor()

        # Insert Teams
        teams = [
            ("India", "IND", "India", ""), ("Australia", "AUS", "Australia", ""),
            ("England", "ENG", "England", ""), ("South Africa", "SA", "South Africa", ""),
            ("New Zealand", "NZ", "New Zealand", ""), ("Pakistan", "PAK", "Pakistan", ""),
            ("Sri Lanka", "SL", "Sri Lanka", ""), ("Bangladesh", "BAN", "Bangladesh", ""),
            ("West Indies", "WI", "West Indies", ""), ("Afghanistan", "AFG", "Afghanistan", "")
        ]
        cursor.executemany("INSERT IGNORE INTO teams (name, short_name, country, image_url) VALUES (%s, %s, %s, %s)", teams)

        # Insert Venues
        venues = [
            ("Wankhede Stadium", "Mumbai", "India", 33000), ("Melbourne Cricket Ground", "Melbourne", "Australia", 100024),
            ("Lord's Cricket Ground", "London", "England", 30000), ("Eden Gardens", "Kolkata", "India", 68000),
            ("Sydney Cricket Ground", "Sydney", "Australia", 48000), ("The Oval", "London", "England", 25500),
            ("Narendra Modi Stadium", "Ahmedabad", "India", 132000), ("Galle International Stadium", "Galle", "Sri Lanka", 35000),
            ("Dubai International Cricket Stadium", "Dubai", "UAE", 25000), ("Newlands Cricket Ground", "Cape Town", "South Africa", 25000)
        ]
        cursor.executemany("INSERT IGNORE INTO venues (name, city, country, capacity) VALUES (%s, %s, %s, %s)", venues)

        # Insert Players
        players_data = [
            ("Virat Kohli", "Virat Kohli", "India", "Batsman", "Right Handed Bat", "Right-arm medium", "1988-11-05"), # ID 1
            ("Rohit Sharma", "Rohit Gurunath Sharma", "India", "Batsman", "Right Handed Bat", "Right-arm offbreak", "1987-04-30"), # ID 2
            ("Jasprit Bumrah", "Jasprit Jasbirsingh Bumrah", "India", "Bowler", "Right Handed Bat", "Right-arm fast", "1993-12-06"), # ID 3
            ("Steve Smith", "Steven Peter Devereux Smith", "Australia", "Batsman", "Right Handed Bat", "Right-arm leg break", "1989-06-02"), # ID 4
            ("Pat Cummins", "Patrick James Cummins", "Australia", "Bowler", "Right Handed Bat", "Right-arm fast", "1993-05-08"), # ID 5
            ("Joe Root", "Joseph Edward Root", "England", "Batsman", "Right Handed Bat", "Right-arm offbreak", "1990-12-30"), # ID 6
            ("Ben Stokes", "Benjamin Andrew Stokes", "England", "All-rounder", "Left Handed Bat", "Right-arm fast-medium", "1991-06-04"), # ID 7
            ("Kane Williamson", "Kane Stuart Williamson", "New Zealand", "Batsman", "Right Handed Bat", "Right-arm offbreak", "1990-08-08"), # ID 8
            ("Babar Azam", "Babar Azam", "Pakistan", "Batsman", "Right Handed Bat", "Right-arm offbreak", "1994-10-15"), # ID 9
            ("Ravindra Jadeja", "Ravindrasinh Anirudhsinh Jadeja", "India", "All-rounder", "Left Handed Bat", "Slow left-arm orthodox", "1988-12-06"), # ID 10
            ("Kagiso Rabada", "Kagiso Rabada", "South Africa", "Bowler", "Left Handed Bat", "Right-arm fast", "1995-05-25"), # ID 11
            ("Rashid Khan", "Rashid Khan Arman", "Afghanistan", "Bowler", "Right Handed Bat", "Right-arm leg break", "1998-09-20"), # ID 12
            ("Shakib Al Hasan", "Shakib Al Hasan", "Bangladesh", "All-rounder", "Left Handed Bat", "Slow left-arm orthodox", "1987-03-24"), # ID 13
            ("KL Rahul", "Kannur Lokesh Rahul", "India", "Wicket-keeper", "Right Handed Bat", "Right-arm medium", "1992-04-18"), # ID 14
            ("Mitchell Starc", "Mitchell Aaron Starc", "Australia", "Bowler", "Left Handed Bat", "Left-arm fast", "1990-01-30"), # ID 15
            ("Quinton de Kock", "Quinton de Kock", "South Africa", "Wicket-keeper", "Left Handed Bat", "Right-arm medium", "1992-12-17"), # ID 16
            ("Trent Boult", "Trent Alexander Boult", "New Zealand", "Bowler", "Right Handed Bat", "Left-arm fast", "1989-07-22"), # ID 17
            ("Hardik Pandya", "Hardik Himanshu Pandya", "India", "All-rounder", "Right Handed Bat", "Right-arm fast-medium", "1993-10-11"), # ID 18
            ("David Warner", "David Andrew Warner", "Australia", "Batsman", "Left Handed Bat", "Right-arm leg break", "1986-10-27"), # ID 19
            ("Shubman Gill", "Shubman Gill", "India", "Batsman", "Right Handed Bat", "Right-arm medium", "1999-09-08") # ID 20
        ]
        cursor.executemany(
            "INSERT IGNORE INTO players (name, full_name, country, playing_role, batting_style, bowling_style, date_of_birth) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            players_data
        )

        # Insert Series
        series_data = [
            ("ICC Cricket World Cup 2023", "India", "ODI", "2023-10-05", "2023-11-19", 48), # ID 1
            ("Border-Gavaskar Trophy 2024", "Australia", "Test", "2024-11-22", "2025-01-07", 5), # ID 2
            ("IPL 2024", "India", "T20", "2024-03-22", "2024-05-26", 74), # ID 3
            ("T20 World Cup 2024", "USA", "T20", "2024-06-01", "2024-06-29", 55), # ID 4
            ("The Ashes 2023", "England", "Test", "2023-06-16", "2023-07-31", 5), # ID 5
            ("Asia Cup 2023", "Pakistan", "ODI", "2023-08-30", "2023-09-17", 13), # ID 6
            ("IND vs ENG Test Series 2024", "India", "Test", "2024-01-25", "2024-03-07", 5), # ID 7
            ("SA vs IND ODI Series 2024", "South Africa", "ODI", "2024-12-01", "2024-12-22", 3), # ID 8
            ("NZ vs AUS T20 Series 2024", "New Zealand", "T20", "2024-02-10", "2024-02-18", 3), # ID 9
            ("WC Qualifiers 2024", "Zimbabwe", "ODI", "2024-06-15", "2024-07-09", 20) # ID 10
        ]
        cursor.executemany(
            "INSERT IGNORE INTO series (name, host_country, match_type, start_date, end_date, total_matches) VALUES (%s, %s, %s, %s, %s, %s)",
            series_data
        )

        # Insert Matches
        matches = [
            ("IND vs AUS - 1st Test", "Test", 1, 2, 1, 2, "2024-11-22 09:30:00", "Complete", 2, "Bat", 2, 184, "runs"), # Match ID 1
            ("IND vs AUS - 2nd Test", "Test", 1, 2, 4, 2, "2024-12-06 09:30:00", "Complete", 1, "Bat", 1, 10, "wickets"), # Match ID 2
            ("IND vs ENG - 1st Test", "Test", 1, 3, 7, 7, "2024-01-25 09:30:00", "Complete", 1, "Bat", 1, 28, "runs"), # Match ID 3
            ("IND vs ENG - 2nd Test", "Test", 1, 3, 1, 7, "2024-02-02 09:30:00", "Complete", 3, "Bowl", 1, 106, "runs"), # Match ID 4
            ("T20 WC Final - IND vs SA", "T20", 1, 4, 9, 4, "2024-06-29 14:00:00", "Complete", 4, "Bat", 1, 7, "runs"), # Match ID 5
            ("ODI WC Final - IND vs AUS", "ODI", 1, 2, 7, 1, "2023-11-19 14:00:00", "Complete", 1, "Bat", 2, 6, "wickets"), # Match ID 6
            ("Ashes - 1st Test", "Test", 3, 2, 6, 5, "2023-06-16 11:00:00", "Complete", 3, "Bowl", 2, 2, "wickets"), # Match ID 7
            ("IND vs NZ - 1st ODI", "ODI", 1, 5, 1, 1, "2024-01-18 13:30:00", "Complete", 1, "Bat", 1, 168, "runs"), # Match ID 8
            ("AUS vs NZ - 1st T20", "T20", 2, 5, 5, 9, "2024-02-10 18:00:00", "Complete", 2, "Bowl", 2, 34, "runs"), # Match ID 9
            ("IND vs PAK - Asia Cup", "ODI", 1, 6, 8, 6, "2023-09-02 14:30:00", "Complete", 6, "Bowl", 1, 228, "runs"), # Match ID 10
            ("SA vs IND - 1st ODI", "ODI", 4, 1, 10, 8, "2024-12-01 13:30:00", "Complete", 4, "Bat", 1, 61, "runs"), # Match ID 11
            ("IND vs AUS - 3rd Test", "Test", 1, 2, 2, 2, "2024-12-14 09:30:00", "Complete", 1, "Bowl", 2, 3, "wickets"), # Match ID 12
            ("ENG vs AUS - 2nd Test", "Test", 3, 2, 3, 5, "2023-06-28 11:00:00", "Complete", 3, "Bat", 3, 49, "runs"), # Match ID 13
            ("NZ vs IND - 1st Test", "Test", 5, 1, 8, 1, "2024-10-16 09:30:00", "Complete", 5, "Bowl", 5, 8, "wickets"), # Match ID 14
            ("IND vs BAN - 1st ODI", "ODI", 1, 8, 1, 1, "2024-09-15 13:30:00", "Complete", 1, "Bat", 1, 93, "runs"), # Match ID 15
            ("PAK vs NZ - 1st T20", "T20", 6, 5, 9, 8, "2024-04-18 19:00:00", "Complete", 6, "Bowl", 5, 4, "wickets"), # Match ID 16
            ("SA vs AUS - 1st ODI", "ODI", 4, 2, 10, 8, "2024-09-05 13:30:00", "Complete", 2, "Bat", 4, 25, "runs"), # Match ID 17
            ("IND vs WI - 1st T20", "T20", 1, 9, 1, 1, "2024-07-26 19:30:00", "Complete", 1, "Bat", 1, 43, "runs"), # Match ID 18
            ("IND vs AFG - 1st T20", "T20", 1, 10, 7, 4, "2024-01-11 19:00:00", "Complete", 10, "Bat", 1, 6, "wickets"), # Match ID 19
            ("AUS vs ENG - 3rd Test", "Test", 2, 3, 5, 5, "2023-07-06 11:00:00", "Complete", 2, "Bat", 2, 3, "wickets") # Match ID 20
        ]
        cursor.executemany(
            """INSERT IGNORE INTO matches
            (description, match_format, team1_id, team2_id, venue_id, series_id,
            match_date, status, toss_winner_id, toss_decision, winner_id, victory_margin, victory_type)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            matches
        )

        # Insert Career Stats (player_id and match_format are crucial)
        career_stats = [
            # Virat Kohli (Player ID 1)
            (1, "Test", 113, 8848, 49.15, 57.10, 29, 30, 254, 0, 0.00, 0.00, 109, 0, 0.00),
            (1, "ODI", 292, 13848, 58.07, 93.25, 50, 72, 183, 4, 166.00, 8.11, 130, 0, 122.00),
            (1, "T20", 125, 4008, 52.73, 137.96, 1, 37, 122, 0, 0.00, 0.00, 50, 0, 0.00),
            # Rohit Sharma (Player ID 2)
            (2, "Test", 56, 4117, 46.26, 57.84, 12, 15, 212, 0, 0.00, 0.00, 55, 0, 0.00),
            (2, "ODI", 265, 10709, 49.11, 91.17, 31, 48, 264, 8, 64.75, 5.32, 97, 0, 73.00),
            (2, "T20", 159, 4231, 32.05, 140.89, 4, 32, 121, 0, 0.00, 0.00, 48, 0, 0.00),
            # Jasprit Bumrah (Player ID 3)
            (3, "Test", 38, 206, 8.58, 41.04, 0, 0, 29, 159, 20.54, 2.68, 17, 0, 45.92),
            (3, "ODI", 82, 61, 6.10, 60.40, 0, 0, 14, 149, 24.28, 4.63, 25, 0, 31.42),
            (3, "T20", 68, 19, 19.00, 95.00, 0, 0, 10, 89, 18.23, 6.45, 15, 0, 16.96),
            # Steve Smith (Player ID 4)
            (4, "Test", 109, 9685, 56.36, 54.08, 32, 40, 239, 7, 112.71, 2.97, 137, 0, 227.00),
            (4, "ODI", 138, 4987, 43.34, 87.10, 12, 30, 164, 4, 120.50, 5.56, 56, 0, 129.80),
            (4, "T20", 63, 1165, 26.47, 127.18, 0, 5, 90, 1, 36.00, 9.00, 22, 0, 24.00),
            # Pat Cummins (Player ID 5)
            (5, "Test", 58, 1300, 21.31, 47.27, 0, 4, 54, 216, 22.12, 2.88, 31, 0, 46.03),
            (5, "ODI", 82, 550, 15.71, 88.71, 0, 0, 32, 127, 26.64, 5.04, 30, 0, 31.68),
            (5, "T20", 52, 104, 10.40, 117.98, 0, 0, 16, 60, 22.01, 7.52, 18, 0, 17.58),
            # Joe Root (Player ID 6)
            (6, "Test", 143, 12402, 50.21, 56.58, 35, 63, 254, 49, 45.96, 3.45, 173, 0, 79.93),
            (6, "ODI", 160, 6207, 51.30, 86.83, 16, 36, 133, 29, 47.82, 5.28, 70, 0, 54.34),
            (6, "T20", 35, 893, 35.72, 126.37, 0, 5, 90, 3, 28.67, 7.17, 15, 0, 24.00),
            # Ben Stokes (Player ID 7)
            (7, "Test", 100, 6270, 34.83, 57.80, 12, 28, 258, 200, 31.38, 3.18, 95, 0, 59.10),
            (7, "ODI", 105, 2919, 39.44, 95.20, 3, 21, 182, 74, 41.80, 6.05, 45, 0, 41.40),
            (7, "T20", 40, 585, 20.17, 136.04, 0, 1, 47, 25, 32.64, 8.56, 12, 0, 22.80),
            # Kane Williamson (Player ID 8)
            (8, "Test", 99, 8547, 54.14, 52.49, 31, 34, 251, 28, 41.07, 3.02, 74, 0, 81.60),
            (8, "ODI", 167, 6554, 47.48, 82.23, 13, 41, 148, 37, 36.40, 5.04, 70, 0, 43.33),
            (8, "T20", 87, 2254, 32.20, 122.93, 0, 12, 95, 3, 32.33, 7.38, 32, 0, 26.20),
            # Babar Azam (Player ID 9)
            (9, "Test", 52, 3898, 45.32, 55.38, 9, 26, 196, 1, 52.00, 4.54, 39, 0, 68.60),
            (9, "ODI", 114, 5729, 56.72, 88.96, 19, 32, 158, 1, 162.00, 6.70, 43, 0, 145.00),
            (9, "T20", 108, 3898, 41.04, 129.93, 3, 34, 122, 0, 0.00, 0.00, 30, 0, 0.00),
            # Ravindra Jadeja (Player ID 10)
            (10, "Test", 72, 3047, 36.27, 57.33, 3, 17, 175, 294, 24.10, 2.49, 55, 0, 48.00),
            (10, "ODI", 177, 2756, 32.42, 86.51, 0, 13, 87, 220, 36.20, 4.89, 62, 0, 44.50),
            (10, "T20", 74, 515, 18.39, 127.16, 0, 0, 46, 51, 29.45, 7.19, 20, 0, 24.60),
            # Kagiso Rabada (Player ID 11)
            (11, "Test", 58, 762, 14.11, 47.48, 0, 2, 45, 272, 21.87, 3.25, 21, 0, 45.90),
            (11, "ODI", 91, 297, 11.88, 78.36, 0, 0, 23, 142, 28.49, 5.20, 18, 0, 32.10),
            (11, "T20", 45, 50, 5.00, 100.00, 0, 0, 10, 41, 24.50, 8.25, 12, 0, 17.80),
            # Rashid Khan (Player ID 12)
            (12, "Test", 6, 218, 36.33, 64.31, 0, 1, 55, 34, 22.03, 2.85, 3, 0, 46.30),
            (12, "ODI", 86, 983, 19.27, 99.80, 0, 2, 60, 163, 18.16, 4.15, 35, 0, 26.20),
            (12, "T20", 80, 413, 11.47, 152.40, 0, 0, 42, 130, 14.08, 6.18, 28, 0, 13.60),
            # Shakib Al Hasan (Player ID 13)
            (13, "Test", 66, 4467, 38.52, 55.68, 5, 31, 217, 237, 31.12, 2.86, 42, 0, 65.40),
            (13, "ODI", 237, 7510, 37.17, 80.23, 9, 55, 134, 295, 31.36, 4.72, 51, 0, 39.80),
            (13, "T20", 117, 2340, 22.71, 120.86, 0, 12, 70, 134, 20.81, 6.61, 38, 0, 18.90),
            # KL Rahul (Player ID 14)
            (14, "Test", 50, 2981, 34.66, 50.94, 8, 11, 149, 0, 0.00, 0.00, 62, 4, 0.00),
            (14, "ODI", 56, 2199, 45.81, 87.35, 5, 15, 112, 0, 0.00, 0.00, 24, 8, 0.00),
            (14, "T20", 72, 2265, 37.75, 139.12, 0, 22, 110, 0, 0.00, 0.00, 20, 6, 0.00),
            # Mitchell Starc (Player ID 15)
            (15, "Test", 79, 1362, 17.46, 47.60, 0, 3, 99, 358, 25.84, 3.36, 18, 0, 46.00),
            (15, "ODI", 107, 635, 12.94, 85.47, 0, 0, 36, 222, 22.43, 4.97, 28, 0, 27.00),
            (15, "T20", 52, 123, 12.30, 150.00, 0, 0, 32, 62, 20.50, 7.26, 11, 0, 16.90),
            # Quinton de Kock (Player ID 16)
            (16, "Test", 54, 3300, 38.37, 70.92, 6, 18, 141, 0, 0.00, 0.00, 82, 16, 0.00),
            (16, "ODI", 149, 5765, 44.96, 96.79, 17, 27, 178, 0, 0.00, 0.00, 74, 32, 0.00),
            (16, "T20", 92, 2456, 30.07, 139.00, 0, 17, 99, 0, 0.00, 0.00, 22, 18, 0.00),
            # Trent Boult (Player ID 17)
            (17, "Test", 80, 699, 13.44, 48.55, 0, 2, 71, 317, 27.50, 3.10, 22, 0, 51.50),
            (17, "ODI", 98, 190, 7.60, 70.11, 0, 0, 21, 187, 24.26, 4.89, 25, 0, 30.00),
            (17, "T20", 52, 42, 6.00, 105.00, 0, 0, 12, 62, 21.44, 7.85, 10, 0, 18.00),
            # Hardik Pandya (Player ID 18)
            (18, "Test", 11, 532, 31.29, 68.56, 1, 2, 83, 17, 31.64, 3.47, 5, 0, 54.60),
            (18, "ODI", 80, 2195, 36.58, 104.32, 0, 15, 92, 72, 35.67, 5.56, 17, 0, 38.40),
            (18, "T20", 108, 1271, 18.73, 142.57, 0, 3, 63, 84, 24.82, 8.53, 36, 0, 20.00),
            # David Warner (Player ID 19)
            (19, "Test", 112, 8786, 44.59, 70.19, 26, 34, 335, 4, 123.50, 3.94, 102, 0, 150.00),
            (19, "ODI", 161, 6932, 45.27, 97.38, 22, 33, 179, 0, 0.00, 0.00, 57, 0, 0.00),
            (19, "T20", 99, 2894, 33.27, 142.47, 1, 22, 100, 2, 48.00, 8.73, 35, 0, 25.00),
            # Shubman Gill (Player ID 20)
            (20, "Test", 30, 1798, 35.96, 60.43, 5, 9, 128, 0, 0.00, 0.00, 20, 0, 0.00),
            (20, "ODI", 44, 2328, 58.20, 99.10, 7, 12, 208, 0, 0.00, 0.00, 18, 0, 0.00),
            (20, "T20", 37, 920, 28.75, 142.44, 0, 6, 126, 0, 0.00, 0.00, 10, 0, 0.00)
        ]
        cursor.executemany(
            """INSERT IGNORE INTO career_stats
            (player_id, match_format, matches_played, total_runs, batting_average, strike_rate,
            centuries, half_centuries, highest_score, total_wickets, bowling_average, bowling_economy,
            catches, stumpings, bowling_strike_rate)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            career_stats
        )

        # Insert Batting Stats (match_id and player_id need to correspond to existing data)
        batting_stats = [
            (1, 1, 1, 5, 12, 0, 0, 41.67, 3, False), (1, 2, 1, 100, 143, 8, 2, 69.93, 3, True),
            (2, 1, 1, 3, 10, 0, 0, 30.00, 1, False), (2, 2, 1, 47, 72, 6, 1, 65.28, 1, False),
            (4, 1, 1, 104, 189, 10, 2, 55.03, 3, False), (4, 2, 1, 1, 4, 0, 0, 25.00, 3, False),
            (6, 3, 1, 218, 358, 26, 0, 60.89, 3, True), (6, 4, 1, 8, 24, 1, 0, 33.33, 3, False),
            (7, 3, 1, 70, 88, 6, 4, 79.55, 5, False), (7, 7, 1, 50, 63, 5, 2, 79.37, 5, True),
            (1, 5, 1, 76, 59, 4, 4, 128.81, 3, False), (2, 5, 1, 47, 31, 2, 3, 151.61, 1, False),
            (1, 6, 1, 54, 63, 6, 1, 85.71, 3, False), (2, 6, 1, 40, 55, 4, 0, 72.73, 1, False),
            (4, 6, 1, 71, 82, 9, 0, 86.59, 3, False), (8, 8, 1, 56, 78, 5, 1, 71.79, 3, False),
            (9, 10, 1, 10, 22, 1, 0, 45.45, 3, False), (20, 8, 1, 116, 97, 12, 4, 119.59, 1, False),
            (20, 11, 1, 53, 61, 6, 1, 86.89, 1, False), (14, 5, 1, 39, 28, 3, 2, 139.29, 5, True),
            (19, 9, 1, 45, 32, 4, 2, 140.63, 1, False), (16, 11, 1, 80, 92, 8, 2, 86.96, 1, False),
            (18, 5, 1, 27, 18, 2, 2, 150.00, 6, True), (18, 18, 1, 40, 26, 3, 3, 153.85, 6, False),
            (1, 15, 1, 88, 99, 10, 2, 88.89, 3, False), (2, 15, 1, 72, 56, 9, 2, 128.57, 1, False),
            (20, 15, 1, 41, 52, 4, 1, 78.85, 3, False), (1, 18, 1, 37, 28, 4, 1, 132.14, 3, False),
            (2, 18, 1, 55, 36, 5, 3, 152.78, 1, False), (14, 19, 1, 68, 50, 7, 3, 136.00, 5, False)
        ]
        cursor.executemany(
            """INSERT IGNORE INTO batting_stats
            (player_id, match_id, innings, runs_scored, balls_faced, fours, sixes, strike_rate, batting_position, is_not_out)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            batting_stats
        )

        # Insert Bowling Stats (match_id and player_id need to correspond to existing data)
        bowling_stats = [
            (3, 1, 1, 25.0, 56, 4, 2, 2.24), (3, 2, 1, 20.0, 48, 5, 3, 2.40),
            (5, 1, 1, 28.0, 68, 3, 0, 2.43), (5, 2, 1, 22.0, 78, 2, 0, 3.55),
            (10, 3, 1, 30.0, 70, 5, 4, 2.33), (10, 4, 1, 25.0, 55, 4, 1, 2.20),
            (7, 7, 1, 20.0, 65, 3, 0, 3.25), (3, 5, 1, 4.0, 18, 2, 0, 4.50),
            (15, 6, 1, 10.0, 45, 3, 0, 4.50), (15, 9, 1, 4.0, 32, 2, 0, 8.00),
            (11, 11, 1, 10.0, 38, 3, 0, 3.80), (11, 17, 1, 10.0, 52, 2, 0, 5.20),
            (17, 14, 1, 22.0, 55, 4, 2, 2.50), (17, 16, 1, 4.0, 28, 2, 0, 7.00),
            (12, 19, 1, 4.0, 22, 3, 0, 5.50), (5, 7, 1, 24.0, 70, 4, 0, 2.92),
            (5, 20, 1, 22.0, 58, 3, 0, 2.64), (15, 7, 1, 22.0, 72, 3, 0, 3.27),
            (15, 20, 1, 25.0, 60, 4, 0, 2.40), (3, 14, 1, 18.0, 62, 3, 0, 3.44)
        ]
        cursor.executemany(
            """INSERT IGNORE INTO bowling_stats
            (player_id, match_id, innings, overs_bowled, runs_conceded, wickets_taken, maidens, economy_rate)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
            bowling_stats
        )

        conn.commit()
        print("Sample data inserted successfully!")

    except Error as e:
        print(f"Error inserting data: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

if __name__ == "__main__":
    create_database_and_tables()
    insert_sample_data()