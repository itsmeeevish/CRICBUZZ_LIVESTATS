import streamlit as st
import requests
import pandas as pd
from utils.db_connection import execute_query

# API Configuration
RAPIDAPI_KEY = "343ded2500mshed0e2b637b3f291p154059jsnc16cffc014d9"
RAPIDAPI_HOST = "cricbuzz-cricket.p.rapidapi.com"

HEADERS = {
    "x-rapidapi-key": RAPIDAPI_KEY,
    "x-rapidapi-host": RAPIDAPI_HOST
}

# Correct stat type values (as per API)
BATTING_STATS = {
    "Most Runs": "mostRuns",
    "Highest Score": "highestScore",
    "Best Batting Average": "highestAvg",
    "Best Strike Rate": "highestSr",
    "Most Hundreds": "mostHundreds",
    "Most Fifties": "mostFifties",
    "Most Fours": "mostFours",
    "Most Sixes": "mostSixes",
    "Most Nineties": "mostNineties"
}

BOWLING_STATS = {
    "Most Wickets": "mostWickets",
    "Best Bowling Average": "lowestAvg",
    "Best Bowling Innings": "bestBowlingInnings",
    "Most 5 Wicket Hauls": "mostFiveWickets",
    "Best Economy": "lowestEcon",
    "Best Bowling Strike Rate": "lowestSr"
}

# Combine all stats
ALL_STATS = {**BATTING_STATS, **BOWLING_STATS}

FORMAT_MAP = {
    "Test": "test",
    "ODI": "odi",
    "T20I": "t20i"
}

FORMAT_MAP_DB = {
    "Test": "Test",
    "ODI": "ODI",
    "T20I": "T20"
}


def fetch_stats_from_api(stat_type_value, format_value):
    """Fetch stats from Cricbuzz API."""
    url = f"https://{RAPIDAPI_HOST}/stats/v1/topstats"
    params = {
        "statsType": stat_type_value,
        "statsFormat": format_value
    }
    
    try:
        res = requests.get(url, headers=HEADERS, params=params, timeout=15)
        res.raise_for_status()
        return res.json()
    except requests.exceptions.HTTPError as e:
        st.error(f"❌ API Error {e.response.status_code}: Check API key/quota")
    except requests.exceptions.Timeout:
        st.error("⏰ API Timeout")
    except requests.exceptions.ConnectionError:
        st.error("🚫 Connection Error")
    except Exception as e:
        st.error(f"Error: {e}")
    return None


def parse_api_response(api_data):
    """Parse the API response into a clean DataFrame."""
    if not api_data:
        return None
    
    # Get headers from API response
    headers = api_data.get("headers", [])
    values_list = api_data.get("values", [])
    
    if not headers or not values_list:
        return None
    
    # Build rows - skip first value (ID) in each row
    rows = []
    for item in values_list:
        if isinstance(item, dict) and "values" in item:
            val = item["values"]
            if len(val) >= 2:
                # First value is ID, skip it
                # Map remaining values to headers
                row = {}
                for i, header in enumerate(headers):
                    # val[0] is ID, so actual data starts from val[1]
                    data_index = i + 1
                    if data_index < len(val):
                        cell_value = val[data_index]
                        # Clean None values
                        if cell_value is None or cell_value == "None" or cell_value == "":
                            row[header] = "—"
                        else:
                            row[header] = cell_value
                    else:
                        row[header] = "—"
                rows.append(row)
    
    if rows:
        df = pd.DataFrame(rows)
        # Add Rank column
        df.insert(0, "Rank", range(1, len(df) + 1))
        return df
    
    return None


def fetch_stats_from_db(stat_type_key, format_key):
    """Fallback: Fetch stats from local database."""
    db_format = FORMAT_MAP_DB.get(format_key, "ODI")
    
    is_bowling = stat_type_key in BOWLING_STATS
    
    if is_bowling:
        query = f"""
            SELECT p.name AS Player, p.country AS Country,
                   cs.matches_played AS M, cs.total_wickets AS W,
                   ROUND(cs.bowling_average, 2) AS Avg, 
                   ROUND(cs.bowling_economy, 2) AS Econ
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            WHERE cs.match_format = '{db_format}' AND cs.total_wickets > 0
            ORDER BY cs.total_wickets DESC
            LIMIT 20;
        """
    else:
        query = f"""
            SELECT p.name AS Player, p.country AS Country,
                   cs.matches_played AS M, cs.total_runs AS R,
                   ROUND(cs.batting_average, 2) AS Avg, 
                   cs.centuries AS '100s', cs.half_centuries AS '50s'
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            WHERE cs.match_format = '{db_format}' AND cs.total_runs > 0
            ORDER BY cs.total_runs DESC
            LIMIT 20;
        """
    
    result = execute_query(query)
    if result:
        df = pd.DataFrame(result)
        df.insert(0, "Rank", range(1, len(df) + 1))
        return df
    return None


# ==================== PAGE CONTENT ====================

st.title("📊 Top Player Statistics")
st.markdown("---")

# Category selection
category = st.radio("Select Category:", ["🏏 Batting", "🎯 Bowling"], horizontal=True)

# Get stats based on category
if "Batting" in category:
    stat_options = list(BATTING_STATS.keys())
else:
    stat_options = list(BOWLING_STATS.keys())

# Selection dropdowns
col1, col2 = st.columns(2)
with col1:
    selected_stat = st.selectbox("📈 Select Statistic", stat_options)
with col2:
    selected_format = st.selectbox("🏏 Select Format", list(FORMAT_MAP.keys()))

st.markdown("---")
st.subheader(f"📋 {selected_stat} — {selected_format}")

# Get API parameter value
stat_value = ALL_STATS[selected_stat]
format_value = FORMAT_MAP[selected_format]

# Fetch data
with st.spinner(f"Fetching {selected_stat} for {selected_format}..."):
    api_data = fetch_stats_from_api(stat_value, format_value)

if api_data:
    df = parse_api_response(api_data)
    
    if df is not None and not df.empty:
        st.success(f"✅ Showing Top {len(df)} players from Cricbuzz API")
        
        # Display dataframe with styling
        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Rank": st.column_config.NumberColumn("🏆 Rank", width="small"),
            }
        )
        
        # Download button
        csv = df.to_csv(index=False)
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name=f"{selected_stat.replace(' ', '_')}_{selected_format}.csv",
            mime="text/csv"
        )
    else:
        st.warning("⚠️ Could not parse API response. Showing database data...")
        db_df = fetch_stats_from_db(selected_stat, selected_format)
        if db_df is not None:
            st.dataframe(db_df, use_container_width=True, hide_index=True)
        else:
            st.error("No data available.")
else:
    st.warning("⚠️ API unavailable. Loading from database...")
    
    db_df = fetch_stats_from_db(selected_stat, selected_format)
    
    if db_df is not None and not db_df.empty:
        st.success(f"✅ Showing {len(db_df)} players from local database")
        st.dataframe(db_df, use_container_width=True, hide_index=True)
        
        csv = db_df.to_csv(index=False)
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name=f"{selected_stat.replace(' ', '_')}_{selected_format}_db.csv",
            mime="text/csv"
        )
    else:
        st.error("❌ No data available. Please run `python utils/db_connection.py`")

# Show filter info
with st.expander("ℹ️ About This Data"):
    st.markdown(f"""
    - **Statistic:** {selected_stat}
    - **Format:** {selected_format}
    - **API Parameter:** `statsType={stat_value}`, `statsFormat={format_value}`
    - **Source:** Cricbuzz API via RapidAPI
    """)