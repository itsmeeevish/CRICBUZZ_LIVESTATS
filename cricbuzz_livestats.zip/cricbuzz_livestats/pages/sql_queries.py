import streamlit as st
import pandas as pd
from utils.db_connection import execute_query


def get_all_queries():
    """
    25 SQL practice queries based on the schema used in utils/db_connection.py
    (players, teams, venues, series, matches, batting_stats, bowling_stats, career_stats)
    """
    return {
        # ---------------- Beginner (Q1-Q8) ----------------
        "Q1: Players who represent India": """
            SELECT
                p.full_name,
                p.playing_role,
                p.batting_style,
                p.bowling_style
            FROM players p
            WHERE p.country = 'India'
            ORDER BY p.full_name;
        """,

        "Q2: Matches played in last 30 days": """
            SELECT
                m.description,
                t1.name AS team1,
                t2.name AS team2,
                CONCAT(v.name, ' - ', v.city) AS venue_city,
                m.match_date
            FROM matches m
            JOIN teams t1 ON m.team1_id = t1.team_id
            JOIN teams t2 ON m.team2_id = t2.team_id
            JOIN venues v ON m.venue_id = v.venue_id
            WHERE m.match_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ORDER BY m.match_date DESC;
        """,

        "Q3: Top 10 ODI run scorers": """
            SELECT
                p.name AS player_name,
                cs.total_runs,
                cs.batting_average,
                cs.centuries
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            WHERE cs.match_format = 'ODI'
            ORDER BY cs.total_runs DESC
            LIMIT 10;
        """,

        "Q4: Venues with capacity > 50,000": """
            SELECT
                v.name AS venue_name,
                v.city,
                v.country,
                v.capacity
            FROM venues v
            WHERE v.capacity > 50000
            ORDER BY v.capacity DESC;
        """,

        "Q5: Matches won by each team": """
            SELECT
                t.name AS team_name,
                COUNT(*) AS total_wins
            FROM matches m
            JOIN teams t ON m.winner_id = t.team_id
            WHERE m.winner_id IS NOT NULL
            GROUP BY t.name
            ORDER BY total_wins DESC;
        """,

        "Q6: Players count by playing role": """
            SELECT
                p.playing_role,
                COUNT(*) AS player_count
            FROM players p
            GROUP BY p.playing_role
            ORDER BY player_count DESC;
        """,

        "Q7: Highest individual batting score in each format": """
            SELECT
                cs.match_format,
                MAX(cs.highest_score) AS highest_score
            FROM career_stats cs
            GROUP BY cs.match_format
            ORDER BY cs.match_format;
        """,

        "Q8: Series started in 2024": """
            SELECT
                s.name AS series_name,
                s.host_country,
                s.match_type,
                s.start_date,
                s.total_matches
            FROM series s
            WHERE YEAR(s.start_date) = 2024
            ORDER BY s.start_date;
        """,

        # ---------------- Intermediate (Q9-Q16) ----------------
        "Q9: All-rounders with >1000 runs AND >50 wickets": """
            SELECT
                p.name AS player_name,
                cs.match_format,
                cs.total_runs,
                cs.total_wickets
            FROM players p
            JOIN career_stats cs ON p.player_id = cs.player_id
            WHERE p.playing_role = 'All-rounder'
              AND cs.total_runs > 1000
              AND cs.total_wickets > 50
            ORDER BY cs.total_runs DESC, cs.total_wickets DESC;
        """,

        "Q10: Last 20 completed matches": """
            SELECT
                m.description,
                t1.name AS team1,
                t2.name AS team2,
                wt.name AS winning_team,
                m.victory_margin,
                m.victory_type,
                v.name AS venue_name,
                m.match_date
            FROM matches m
            JOIN teams t1 ON m.team1_id = t1.team_id
            JOIN teams t2 ON m.team2_id = t2.team_id
            LEFT JOIN teams wt ON m.winner_id = wt.team_id
            JOIN venues v ON m.venue_id = v.venue_id
            WHERE m.status = 'Complete'
            ORDER BY m.match_date DESC
            LIMIT 20;
        """,

        "Q11: Player performance across formats (runs pivot + overall avg)": """
            SELECT
                p.name AS player_name,
                MAX(CASE WHEN cs.match_format = 'Test' THEN cs.total_runs END) AS test_runs,
                MAX(CASE WHEN cs.match_format = 'ODI'  THEN cs.total_runs END) AS odi_runs,
                MAX(CASE WHEN cs.match_format = 'T20'  THEN cs.total_runs END) AS t20_runs,
                ROUND(AVG(cs.batting_average), 2) AS overall_batting_avg,
                COUNT(DISTINCT cs.match_format) AS formats_played
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            GROUP BY p.player_id, p.name
            HAVING COUNT(DISTINCT cs.match_format) >= 2
            ORDER BY overall_batting_avg DESC;
        """,

        "Q12: Team wins at home vs away (based on venue country)": """
            SELECT
                t.name AS team_name,
                SUM(CASE WHEN v.country = t.country THEN 1 ELSE 0 END) AS home_wins,
                SUM(CASE WHEN v.country <> t.country THEN 1 ELSE 0 END) AS away_wins
            FROM matches m
            JOIN teams t ON m.winner_id = t.team_id
            JOIN venues v ON m.venue_id = v.venue_id
            WHERE m.winner_id IS NOT NULL
            GROUP BY t.team_id, t.name
            ORDER BY home_wins DESC, away_wins DESC;
        """,

        "Q13: Consecutive batting positions partnership >= 100 (same innings)": """
            SELECT
                p1.name AS batsman_1,
                p2.name AS batsman_2,
                bs1.match_id,
                bs1.innings,
                (bs1.runs_scored + bs2.runs_scored) AS partnership_runs,
                LEAST(bs1.batting_position, bs2.batting_position) AS start_position
            FROM batting_stats bs1
            JOIN batting_stats bs2
              ON bs1.match_id = bs2.match_id
             AND bs1.innings = bs2.innings
             AND ABS(bs1.batting_position - bs2.batting_position) = 1
             AND bs1.player_id < bs2.player_id
            JOIN players p1 ON bs1.player_id = p1.player_id
            JOIN players p2 ON bs2.player_id = p2.player_id
            WHERE (bs1.runs_scored + bs2.runs_scored) >= 100
            ORDER BY partnership_runs DESC;
        """,

        "Q14: Bowling performance by venue (>=3 matches at venue, >=4 overs each match)": """
            SELECT
                p.name AS bowler_name,
                v.name AS venue_name,
                COUNT(*) AS matches_played_at_venue,
                ROUND(AVG(bw.economy_rate), 2) AS avg_economy,
                SUM(bw.wickets_taken) AS total_wickets
            FROM bowling_stats bw
            JOIN players p ON bw.player_id = p.player_id
            JOIN matches m ON bw.match_id = m.match_id
            JOIN venues v ON m.venue_id = v.venue_id
            WHERE bw.overs_bowled >= 4
            GROUP BY p.player_id, p.name, v.venue_id, v.name
            HAVING COUNT(*) >= 3
            ORDER BY avg_economy ASC, total_wickets DESC;
        """,

        "Q15: Close matches performance (decided by <50 runs OR <5 wickets)": """
            WITH close_matches AS (
                SELECT *
                FROM matches
                WHERE winner_id IS NOT NULL
                  AND (
                        (victory_type = 'runs' AND victory_margin < 50)
                     OR (victory_type = 'wickets' AND victory_margin < 5)
                  )
            )
            SELECT
                p.name AS player_name,
                COUNT(DISTINCT bs.match_id) AS close_matches_batted,
                ROUND(AVG(bs.runs_scored), 2) AS avg_runs_in_close_matches,
                SUM(CASE WHEN cm.winner_id IS NOT NULL THEN 1 ELSE 0 END) AS close_matches_with_result
            FROM batting_stats bs
            JOIN close_matches cm ON bs.match_id = cm.match_id
            JOIN players p ON bs.player_id = p.player_id
            GROUP BY p.player_id, p.name
            HAVING COUNT(DISTINCT bs.match_id) >= 2
            ORDER BY avg_runs_in_close_matches DESC;
        """,

        "Q16: Yearly batting performance since 2020 (>=5 matches/year)": """
            SELECT
                p.name AS player_name,
                YEAR(m.match_date) AS yr,
                COUNT(*) AS innings_count,
                ROUND(AVG(bs.runs_scored), 2) AS avg_runs,
                ROUND(AVG(bs.strike_rate), 2) AS avg_strike_rate
            FROM batting_stats bs
            JOIN matches m ON bs.match_id = m.match_id
            JOIN players p ON bs.player_id = p.player_id
            WHERE YEAR(m.match_date) >= 2020
            GROUP BY p.player_id, p.name, YEAR(m.match_date)
            HAVING COUNT(*) >= 5
            ORDER BY p.name, yr;
        """,

        # ---------------- Advanced (Q17-Q25) ----------------
        "Q17: Toss advantage (win % by toss decision)": """
            SELECT
                m.toss_decision,
                COUNT(*) AS total_matches,
                SUM(CASE WHEN m.toss_winner_id = m.winner_id THEN 1 ELSE 0 END) AS toss_winner_won,
                ROUND(
                    100.0 * SUM(CASE WHEN m.toss_winner_id = m.winner_id THEN 1 ELSE 0 END) / COUNT(*),
                    2
                ) AS win_pct
            FROM matches m
            WHERE m.toss_winner_id IS NOT NULL
              AND m.winner_id IS NOT NULL
              AND m.toss_decision IS NOT NULL
            GROUP BY m.toss_decision
            ORDER BY win_pct DESC;
        """,

        "Q18: Most economical bowlers in ODI & T20 (>=10 matches)": """
            SELECT
                p.name AS bowler_name,
                cs.match_format,
                cs.matches_played,
                cs.total_wickets,
                cs.bowling_economy
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            WHERE cs.match_format IN ('ODI', 'T20')
              AND cs.matches_played >= 10
              AND cs.total_wickets > 0
            ORDER BY cs.bowling_economy ASC, cs.total_wickets DESC;
        """,

        "Q19: Consistent batsmen (avg & stddev runs) since 2022, balls>=10": """
            SELECT
                p.name AS player_name,
                COUNT(*) AS innings_count,
                ROUND(AVG(bs.runs_scored), 2) AS avg_runs,
                ROUND(STDDEV_POP(bs.runs_scored), 2) AS stddev_runs
            FROM batting_stats bs
            JOIN matches m ON bs.match_id = m.match_id
            JOIN players p ON bs.player_id = p.player_id
            WHERE YEAR(m.match_date) >= 2022
              AND bs.balls_faced >= 10
            GROUP BY p.player_id, p.name
            HAVING COUNT(*) >= 10
            ORDER BY stddev_runs ASC, avg_runs DESC;
        """,

        "Q20: Matches played & batting avg by format (>=20 total matches)": """
            SELECT
                p.name AS player_name,
                SUM(CASE WHEN cs.match_format = 'Test' THEN cs.matches_played ELSE 0 END) AS test_matches,
                MAX(CASE WHEN cs.match_format = 'Test' THEN cs.batting_average END) AS test_avg,
                SUM(CASE WHEN cs.match_format = 'ODI'  THEN cs.matches_played ELSE 0 END) AS odi_matches,
                MAX(CASE WHEN cs.match_format = 'ODI'  THEN cs.batting_average END) AS odi_avg,
                SUM(CASE WHEN cs.match_format = 'T20'  THEN cs.matches_played ELSE 0 END) AS t20_matches,
                MAX(CASE WHEN cs.match_format = 'T20'  THEN cs.batting_average END) AS t20_avg,
                SUM(cs.matches_played) AS total_matches
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            GROUP BY p.player_id, p.name
            HAVING SUM(cs.matches_played) >= 20
            ORDER BY total_matches DESC;
        """,

        "Q21: Weighted ranking score by format (batting + bowling + fielding)": """
            SELECT
                p.name AS player_name,
                cs.match_format,
                ROUND((cs.total_runs * 0.01) + (cs.batting_average * 0.5) + (cs.strike_rate * 0.3), 2) AS batting_points,
                ROUND(
                    CASE WHEN cs.total_wickets > 0
                        THEN (cs.total_wickets * 2)
                           + ((50 - cs.bowling_average) * 0.5)
                           + ((6 - cs.bowling_economy) * 2)
                        ELSE 0 END
                , 2) AS bowling_points,
                (cs.catches + cs.stumpings) AS fielding_points,
                ROUND(
                    ((cs.total_runs * 0.01) + (cs.batting_average * 0.5) + (cs.strike_rate * 0.3)) +
                    (CASE WHEN cs.total_wickets > 0
                        THEN (cs.total_wickets * 2)
                           + ((50 - cs.bowling_average) * 0.5)
                           + ((6 - cs.bowling_economy) * 2)
                        ELSE 0 END) +
                    (cs.catches + cs.stumpings)
                , 2) AS total_score
            FROM career_stats cs
            JOIN players p ON cs.player_id = p.player_id
            ORDER BY cs.match_format, total_score DESC;
        """,

        "Q22: Head-to-head between teams (last 3 years, >=5 matches)": """
            WITH h2h AS (
                SELECT
                    LEAST(m.team1_id, m.team2_id) AS tmin,
                    GREATEST(m.team1_id, m.team2_id) AS tmax,
                    m.match_id,
                    m.winner_id,
                    m.victory_margin,
                    m.victory_type,
                    m.match_date,
                    m.venue_id
                FROM matches m
                WHERE m.match_date >= DATE_SUB(NOW(), INTERVAL 3 YEAR)
                  AND m.winner_id IS NOT NULL
            )
            SELECT
                tA.name AS team_a,
                tB.name AS team_b,
                COUNT(*) AS total_matches,
                SUM(CASE WHEN winner_id = tA.team_id THEN 1 ELSE 0 END) AS team_a_wins,
                SUM(CASE WHEN winner_id = tB.team_id THEN 1 ELSE 0 END) AS team_b_wins,
                ROUND(AVG(victory_margin), 2) AS avg_victory_margin
            FROM h2h
            JOIN teams tA ON h2h.tmin = tA.team_id
            JOIN teams tB ON h2h.tmax = tB.team_id
            GROUP BY tA.team_id, tA.name, tB.team_id, tB.name
            HAVING COUNT(*) >= 5
            ORDER BY total_matches DESC;
        """,

        "Q23: Recent form (last 10 innings) + category": """
            WITH recent AS (
                SELECT
                    bs.player_id,
                    p.name,
                    bs.runs_scored,
                    bs.strike_rate,
                    m.match_date,
                    ROW_NUMBER() OVER (PARTITION BY bs.player_id ORDER BY m.match_date DESC) AS rn
                FROM batting_stats bs
                JOIN matches m ON bs.match_id = m.match_id
                JOIN players p ON bs.player_id = p.player_id
            )
            SELECT
                name,
                ROUND(AVG(CASE WHEN rn <= 5  THEN runs_scored END), 2) AS avg_last_5,
                ROUND(AVG(CASE WHEN rn <= 10 THEN runs_scored END), 2) AS avg_last_10,
                ROUND(AVG(CASE WHEN rn <= 10 THEN strike_rate END), 2) AS avg_sr_last_10,
                SUM(CASE WHEN rn <= 10 AND runs_scored >= 50 THEN 1 ELSE 0 END) AS fifty_plus_last_10,
                ROUND(STDDEV_POP(CASE WHEN rn <= 10 THEN runs_scored END), 2) AS consistency_stddev,
                CASE
                    WHEN AVG(CASE WHEN rn <= 5 THEN runs_scored END) >= 60 THEN 'Excellent Form'
                    WHEN AVG(CASE WHEN rn <= 5 THEN runs_scored END) >= 40 THEN 'Good Form'
                    WHEN AVG(CASE WHEN rn <= 5 THEN runs_scored END) >= 20 THEN 'Average Form'
                    ELSE 'Poor Form'
                END AS form_category
            FROM recent
            WHERE rn <= 10
            GROUP BY player_id, name
            HAVING COUNT(*) >= 5
            ORDER BY avg_last_5 DESC;
        """,

        "Q24: Successful consecutive partnerships (>=5 partnerships)": """
            WITH partnerships AS (
                SELECT
                    LEAST(bs1.player_id, bs2.player_id) AS pmin,
                    GREATEST(bs1.player_id, bs2.player_id) AS pmax,
                    bs1.match_id,
                    bs1.innings,
                    (bs1.runs_scored + bs2.runs_scored) AS partnership_runs
                FROM batting_stats bs1
                JOIN batting_stats bs2
                  ON bs1.match_id = bs2.match_id
                 AND bs1.innings = bs2.innings
                 AND ABS(bs1.batting_position - bs2.batting_position) = 1
                 AND bs1.player_id < bs2.player_id
            )
            SELECT
                p1.name AS player_1,
                p2.name AS player_2,
                COUNT(*) AS partnerships_count,
                ROUND(AVG(partnership_runs), 2) AS avg_partnership_runs,
                SUM(CASE WHEN partnership_runs > 50 THEN 1 ELSE 0 END) AS partnerships_above_50,
                MAX(partnership_runs) AS highest_partnership,
                ROUND(100.0 * SUM(CASE WHEN partnership_runs > 50 THEN 1 ELSE 0 END) / COUNT(*), 2) AS success_rate_pct
            FROM partnerships pr
            JOIN players p1 ON pr.pmin = p1.player_id
            JOIN players p2 ON pr.pmax = p2.player_id
            GROUP BY p1.player_id, p1.name, p2.player_id, p2.name
            HAVING COUNT(*) >= 5
            ORDER BY avg_partnership_runs DESC;
        """,

        "Q25: Quarterly evolution (avg runs & SR) + trend vs previous quarter": """
            WITH quarterly AS (
                SELECT
                    bs.player_id,
                    p.name,
                    YEAR(m.match_date) AS yr,
                    QUARTER(m.match_date) AS qtr,
                    COUNT(*) AS matches_in_quarter,
                    ROUND(AVG(bs.runs_scored), 2) AS avg_runs,
                    ROUND(AVG(bs.strike_rate), 2) AS avg_sr
                FROM batting_stats bs
                JOIN matches m ON bs.match_id = m.match_id
                JOIN players p ON bs.player_id = p.player_id
                GROUP BY bs.player_id, p.name, YEAR(m.match_date), QUARTER(m.match_date)
                HAVING COUNT(*) >= 3
            ),
            lagged AS (
                SELECT
                    *,
                    LAG(avg_runs) OVER (PARTITION BY player_id ORDER BY yr, qtr) AS prev_avg_runs,
                    COUNT(*) OVER (PARTITION BY player_id) AS total_quarters
                FROM quarterly
            )
            SELECT
                name,
                yr,
                qtr,
                matches_in_quarter,
                avg_runs,
                avg_sr,
                prev_avg_runs,
                CASE
                    WHEN prev_avg_runs IS NULL THEN 'N/A'
                    WHEN avg_runs > prev_avg_runs THEN 'Improving'
                    WHEN avg_runs < prev_avg_runs THEN 'Declining'
                    ELSE 'Stable'
                END AS quarter_trend,
                CASE
                    WHEN total_quarters >= 6 THEN
                        CASE
                            WHEN avg_runs > COALESCE(prev_avg_runs, avg_runs) THEN 'Career Ascending'
                            WHEN avg_runs < COALESCE(prev_avg_runs, avg_runs) THEN 'Career Declining'
                            ELSE 'Career Stable'
                        END
                    ELSE 'Insufficient Data'
                END AS career_phase
            FROM lagged
            ORDER BY name, yr, qtr;
        """,
    }

# --- Page content starts here (top-level execution for Streamlit native multipage) ---
st.title("🔍 SQL Queries & Analytics")
st.markdown("---")

st.info("💡 All SQL queries on this page run against your local MySQL database.")

queries = get_all_queries()
keys = list(queries.keys())

category_options = ["All", "Beginner (Q1-Q8)", "Intermediate (Q9-Q16)", "Advanced (Q17-Q25)"]
selected_category = st.selectbox("📁 Select Category", category_options, key="query_category_select")

filtered_keys = []
if selected_category == "All":
    filtered_keys = keys
elif selected_category == "Beginner (Q1-Q8)":
    filtered_keys = keys[:8]
elif selected_category == "Intermediate (Q9-Q16)":
    filtered_keys = keys[8:16]
elif selected_category == "Advanced (Q17-Q25)":
    filtered_keys = keys[16:]

if not filtered_keys:
    st.warning("No queries found for the selected category.")
else:
    selected_query_title = st.selectbox("🧠 Select a Predefined Query:", filtered_keys, key="predefined_query_select")

    sql = queries[selected_query_title].strip()
    st.code(sql, language="sql")

    if st.button("▶️ Run Selected Query", type="primary"):
        st.subheader(f"Results for: {selected_query_title}")
        result = execute_query(sql)
        if result is None:
            st.error("Query failed. Check DB connection and SQL syntax. (Error messages logged above)")
        elif not result: # result is empty list
            st.info("Query executed successfully but returned 0 rows.")
        else:
            df = pd.DataFrame(result)
            st.success(f"Returned {len(df)} rows.")
            st.dataframe(df, use_container_width=True)

            csv = df.to_csv(index=False)
            st.download_button(
                "📥 Download CSV",
                data=csv,
                file_name=f"{selected_query_title.replace(':', '').replace(' ', '_')}.csv",
                mime="text/csv",
            )

st.markdown("---")
st.subheader("💻 Custom SQL Runner")
custom_sql = st.text_area(
    "Write your own SQL (SELECT-only recommended for safety):",
    height=160,
    placeholder="Example: SELECT name, country FROM players WHERE playing_role = 'All-rounder';",
    key="custom_sql_input"
)

c1, c2 = st.columns([1, 3])
with c1:
    run_custom = st.button("▶️ Run Custom SQL", key="run_custom_sql_button")
with c2:
    st.caption("🚨 Be cautious with custom queries! Avoid UPDATE/DELETE unless you know what you're doing.")

if run_custom:
    if not custom_sql.strip():
        st.warning("Please enter a SQL query to run.")
    else:
        st.subheader("Results for Custom Query:")
        result = execute_query(custom_sql)
        if result is None:
            st.error("Custom query failed. Check SQL syntax. (Error messages logged above)")
        elif not result: # result is empty list
            st.info("Query executed successfully but returned 0 rows (or was a non-SELECT query).")
        else:
            df = pd.DataFrame(result)
            st.success(f"Returned {len(df)} rows.")
            st.dataframe(df, use_container_width=True)