import streamlit as st
import pandas as pd
from mysql.connector import Error

from utils.db_connection import execute_query, get_connection


def show_table_data(table_name: str):
    """Fetches and displays all data from a specified table."""
    result = execute_query(f"SELECT * FROM {table_name}")
    if result is None:
        st.error(f"Failed to fetch data from '{table_name}'. Please check the database connection and logs.")
        return
    if not result:
        st.info(f"No records found in the '{table_name}' table.")
        return
    st.dataframe(pd.DataFrame(result), use_container_width=True)
    st.caption(f"Total rows: {len(result)}")


# --- Page content starts here (top-level execution for Streamlit native multipage) ---
st.title("🛠 CRUD Operations (Database Management)")
st.markdown("---")

st.info("💡 This page allows you to Create, Read, Update, and Delete records in your local MySQL database.")

tab_read, tab_create, tab_update, tab_delete = st.tabs(
    ["📋 Read (View)", "➕ Create (Insert)", "✏️ Update", "🗑️ Delete"]
)

# ---------------- READ Tab ----------------
with tab_read:
    st.subheader("📋 View Database Tables")

    table_options = ["players", "teams", "venues", "series", "matches", "career_stats", "batting_stats", "bowling_stats"]
    selected_table = st.selectbox(
        "Select a table to view its data:",
        table_options,
        key="read_table_selector"
    )
    if st.button(f"🔄 Load Data from {selected_table}", type="primary", key="load_data_button"):
        show_table_data(selected_table)

# ---------------- CREATE Tab ----------------
with tab_create:
    st.subheader("➕ Add New Player")

    with st.form("create_player_form", clear_on_submit=True):
        st.markdown("**Enter New Player Details:**")
        c1, c2 = st.columns(2)

        with c1:
            player_name = st.text_input("Name (e.g., MS Dhoni) *")
            full_name = st.text_input("Full Name (e.g., Mahendra Singh Dhoni)")
            country = st.text_input("Country (e.g., India)", value="India")
            playing_role = st.selectbox("Playing Role", ["Batsman", "Bowler", "All-rounder", "Wicket-keeper"], index=0)
        with c2:
            batting_style = st.selectbox("Batting Style", ["Right Handed Bat", "Left Handed Bat"], index=0)
            bowling_style = st.text_input("Bowling Style (e.g., Right-arm fast-medium)", placeholder="Enter N/A if not applicable")
            date_of_birth = st.date_input("Date of Birth (YYYY-MM-DD)")

        submitted_player = st.form_submit_button("Add Player to Database", type="primary")

    if submitted_player:
        if not player_name.strip():
            st.error("Player Name is required. Please fill it in.")
        else:
            conn = get_connection()
            if conn:
                try:
                    cur = conn.cursor()
                    cur.execute(
                        """
                        INSERT INTO players (name, full_name, country, playing_role, batting_style, bowling_style, date_of_birth)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        """,
                        (player_name, full_name, country, playing_role, batting_style, bowling_style, date_of_birth),
                    )
                    conn.commit()
                    st.success(f"✅ Player '{player_name}' added successfully!")
                except Error as e:
                    st.error(f"❌ Error adding player: {e}")
                finally:
                    conn.close()

    st.markdown("---")
    st.subheader("➕ Add Career Statistics for a Player")

    players_for_stats = execute_query("SELECT player_id, name FROM players ORDER BY name")
    if not players_for_stats:
        st.info("No players found in the database. Please add players first to assign career statistics.")
    else:
        player_map = {f"{p['name']} (ID: {p['player_id']})": p["player_id"] for p in players_for_stats}

        with st.form("create_career_stats_form", clear_on_submit=True):
            st.markdown("**Enter Player Career Stats:**")
            c1, c2, c3 = st.columns(3)
            with c1:
                player_label = st.selectbox("Select Player", list(player_map.keys()), key="cs_player_select")
                player_id = player_map[player_label]
                match_format = st.selectbox("Match Format", ["Test", "ODI", "T20"], key="cs_format")
                matches_played = st.number_input("Matches Played", min_value=0, step=1, value=0)

            with c2:
                total_runs = st.number_input("Total Runs", min_value=0, step=1, value=0)
                batting_avg = st.number_input("Batting Average", min_value=0.0, step=0.01, format="%.2f", value=0.0)
                strike_rate = st.number_input("Strike Rate", min_value=0.0, step=0.01, format="%.2f", value=0.0)
                centuries = st.number_input("Centuries", min_value=0, step=1, value=0)
                half_centuries = st.number_input("Half Centuries", min_value=0, step=1, value=0)

            with c3:
                highest_score = st.number_input("Highest Score", min_value=0, step=1, value=0)
                total_wickets = st.number_input("Total Wickets", min_value=0, step=1, value=0)
                bowling_avg = st.number_input("Bowling Average", min_value=0.0, step=0.01, format="%.2f", value=0.0)
                bowling_econ = st.number_input("Economy Rate", min_value=0.0, step=0.01, format="%.2f", value=0.0)
                catches = st.number_input("Catches", min_value=0, step=1, value=0)
                stumpings = st.number_input("Stumpings", min_value=0, step=1, value=0)

            submitted_career = st.form_submit_button("Add Career Stats", type="primary")

        if submitted_career:
            conn = get_connection()
            if conn:
                try:
                    cur = conn.cursor()
                    cur.execute(
                        """
                        INSERT INTO career_stats
                        (player_id, match_format, matches_played, total_runs, batting_average, strike_rate,
                         centuries, half_centuries, highest_score, total_wickets,
                         bowling_average, bowling_economy, catches, stumpings)
                        VALUES
                        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        (
                            player_id, match_format, matches_played, total_runs, batting_avg, strike_rate,
                            centuries, half_centuries, highest_score, total_wickets,
                            bowling_avg, bowling_econ, catches, stumpings
                        ),
                    )
                    conn.commit()
                    st.success(f"✅ Career stats added for player ID {player_id} ({player_label.split('(')[0].strip()}) in {match_format} format!")
                except Error as e:
                    st.error(f"❌ Error adding career stats: {e}. A player might already have stats for this format.")
                finally:
                    conn.close()

# ---------------- UPDATE Tab ----------------
with tab_update:
    st.subheader("✏️ Update Player Record")
    
    players_to_update = execute_query("SELECT player_id, name FROM players ORDER BY name")
    if not players_to_update:
        st.info("No players found in the database to update.")
    else:
        player_map_update = {f"{p['name']} (ID: {p['player_id']})": p["player_id"] for p in players_to_update}
        chosen_player_label = st.selectbox("Select Player to Update:", list(player_map_update.keys()), key="update_player_select")
        player_id_to_update = player_map_update[chosen_player_label]

        current_player_data = execute_query("SELECT * FROM players WHERE player_id = %s", (player_id_to_update,))
        
        if not current_player_data:
            st.error("Player data not found for the selected ID.") # Should not happen if selectbox is populated correctly
        else:
            curp = current_player_data[0] # Get the first (and only) row
            with st.form("update_player_form"):
                st.markdown(f"**Updating Player: {chosen_player_label}**")
                c1, c2 = st.columns(2)
                with c1:
                    name_upd = st.text_input("Name", value=curp.get("name", ""))
                    full_name_upd = st.text_input("Full Name", value=curp.get("full_name", ""))
                    country_upd = st.text_input("Country", value=curp.get("country", ""))
                    playing_role_upd = st.selectbox("Playing Role", ["Batsman", "Bowler", "All-rounder", "Wicket-keeper"], index=["Batsman", "Bowler", "All-rounder", "Wicket-keeper"].index(curp.get("playing_role", "Batsman")))
                with c2:
                    batting_style_upd = st.selectbox("Batting Style", ["Right Handed Bat", "Left Handed Bat"], index=["Right Handed Bat", "Left Handed Bat"].index(curp.get("batting_style", "Right Handed Bat")))
                    bowling_style_upd = st.text_input("Bowling Style", value=curp.get("bowling_style", ""))
                    date_of_birth_upd = st.date_input("Date of Birth", value=curp.get("date_of_birth"))

                submitted_update = st.form_submit_button("Update Player Details", type="primary")

            if submitted_update:
                conn = get_connection()
                if conn:
                    try:
                        cur = conn.cursor()
                        cur.execute(
                            """
                            UPDATE players
                            SET name=%s, full_name=%s, country=%s, playing_role=%s, batting_style=%s, bowling_style=%s, date_of_birth=%s
                            WHERE player_id=%s
                            """,
                            (name_upd, full_name_upd, country_upd, playing_role_upd, batting_style_upd, bowling_style_upd, date_of_birth_upd, player_id_to_update),
                        )
                        conn.commit()
                        st.success(f"✅ Player '{name_upd}' (ID: {player_id_to_update}) updated successfully!")
                    except Error as e:
                        st.error(f"❌ Error updating player: {e}")
                    finally:
                        conn.close()

# ---------------- DELETE Tab ----------------
with tab_delete:
    st.subheader("🗑️ Delete Player Record")
    st.warning("⚠️ This action is irreversible! Deleting a player will also delete all their associated batting, bowling, and career statistics to maintain data integrity.")

    players_to_delete = execute_query("SELECT player_id, name FROM players ORDER BY name")
    if not players_to_delete:
        st.info("No players found in the database to delete.")
    else:
        player_map_delete = {f"{p['name']} (ID: {p['player_id']})": p["player_id"] for p in players_to_delete}
        chosen_player_label_del = st.selectbox("Select Player to Delete:", list(player_map_delete.keys()), key="delete_player_select")
        player_id_to_delete = player_map_delete[chosen_player_label_del]

        st.markdown(f"**You are about to delete: {chosen_player_label_del}**")
        confirm_delete = st.checkbox(f"I understand and want to permanently delete {chosen_player_label_del} and all their stats.", key="delete_confirm")
        
        if confirm_delete:
            if st.button("🔴 Permanently Delete Player", type="primary", key="execute_delete_button"):
                conn = get_connection()
                if conn:
                    try:
                        cur = conn.cursor()
                        # Delete related records first due to foreign key constraints (CASCADE DELETE not setup)
                        cur.execute("DELETE FROM batting_stats WHERE player_id = %s", (player_id_to_delete,))
                        cur.execute("DELETE FROM bowling_stats WHERE player_id = %s", (player_id_to_delete,))
                        cur.execute("DELETE FROM career_stats WHERE player_id = %s", (player_id_to_delete,))
                        cur.execute("DELETE FROM players WHERE player_id = %s", (player_id_to_delete,)) # Finally delete the player
                        conn.commit()
                        st.success(f"✅ Player '{chosen_player_label_del}' (ID: {player_id_to_delete}) and all related records deleted successfully!")
                        st.rerun() # Rerun to refresh the selectbox after deletion
                    except Error as e:
                        st.error(f"❌ Error deleting player: {e}")
                    finally:
                        conn.close()
                else:
                    st.error("Database connection failed, could not perform delete operation.")