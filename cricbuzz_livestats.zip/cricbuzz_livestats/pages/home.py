import streamlit as st

st.title("🏠 Home: Project Overview")
st.markdown("---")

st.markdown("""
Welcome to **Cricbuzz LiveStats** — a comprehensive cricket analytics dashboard
that integrates live data from the Cricbuzz API with a SQL database to create
an interactive web application.
""")

col1, col2 = st.columns(2)

with col1:
    st.subheader("⚡ Key Features")
    st.markdown("""
    - **Real-time Match Updates**: Live scores and match details from the Cricbuzz API.
    - **Top Player Statistics**: Best batting and bowling performances across different formats.
    - **SQL Analytics Engine**: 25+ predefined SQL queries for deep cricket data analysis, plus a custom query runner.
    - **CRUD Operations**: Full data management (Create, Read, Update, Delete) for player records and career statistics.
    """)

with col2:
    st.subheader("🛠 Technical Stack")
    st.markdown("""
    - **Python**: Core programming language.
    - **Streamlit**: For creating interactive web applications and the user interface.
    - **MySQL Database**: To store structured cricket data for analytics and CRUD operations.
    - **REST API (RapidAPI)**: Integration with the Cricbuzz Cricket API for live and statistical data.
    - **Pandas**: For efficient data manipulation and display within the app.
    """)

st.markdown("---")
st.subheader("📂 Project Structure (Simplified)")
st.code("""
cricbuzz_livestats/
├── app.py                  # Main Streamlit app entry point
├── requirements.txt        # Python dependencies list
├── pages/                  # Streamlit automatically detects pages here
│   ├── home.py             # This project overview page
│   ├── live_matches.py     # Displays live/recent match data
│   ├── top_stats.py        # Shows top batting/bowling statistics
│   ├── sql_queries.py      # Pre-built & custom SQL queries
│   └── crud_operations.py  # CRUD for player records
└── utils/
    └── db_connection.py    # MySQL connection and initial data setup
    """, language="text")

st.markdown("---")
st.subheader("🚀 How to Use")
st.markdown("""
- Use the **left sidebar** to navigate between different sections of the application.
- **Live Matches** page prioritizes real-time API data.
- **Top Stats** page tries API first, then falls back to local database if API fails.
- **SQL Queries** and **CRUD Operations** pages directly interact with the local MySQL database.
""")

st.info("💡 Ensure your MySQL server is running and the database is initialized by running `python utils/db_connection.py` once. Your API key is pre-configured.")