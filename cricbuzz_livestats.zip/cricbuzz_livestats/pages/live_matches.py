import streamlit as st
import requests
import pandas as pd

# Your API key
RAPIDAPI_KEY = "343ded2500mshed0e2b637b3f291p154059jsnc16cffc014d9"
RAPIDAPI_HOST = "cricbuzz-cricket.p.rapidapi.com"

HEADERS = {
    "x-rapidapi-key": RAPIDAPI_KEY,
    "x-rapidapi-host": RAPIDAPI_HOST
}


def fetch_data_from_api(url, params=None):
    """Helper function to fetch data from RapidAPI."""
    try:
        res = requests.get(url, headers=HEADERS, params=params, timeout=15)
        res.raise_for_status()
        return res.json()
    except requests.exceptions.Timeout:
        st.error("⏰ API Request Timeout: The server took too long to respond.")
    except requests.exceptions.ConnectionError:
        st.error("🚫 Connection Error: Could not connect to the API. Check your internet connection.")
    except requests.exceptions.HTTPError as e:
        st.error(f"❌ API HTTP Error: {e.response.status_code} - {e.response.text}")
    except requests.exceptions.RequestException as e:
        st.error(f"An unexpected API error occurred: {e}")
    return None


def fetch_recent_matches():
    """Fetch recent matches from Cricbuzz API."""
    url = f"https://{RAPIDAPI_HOST}/matches/v1/recent"
    return fetch_data_from_api(url)


def fetch_match_scorecard(match_id):
    """Fetch detailed scorecard for a specific match."""
    url = f"https://{RAPIDAPI_HOST}/mcenter/v1/{match_id}/scard"
    return fetch_data_from_api(url)


def safe_value(value, default=0):
    """Return value if not None, else return default."""
    if value is None:
        return default
    return value


def display_scorecard(scard_data):
    """Parse and display scorecard from API response."""
    if not scard_data:
        st.warning("No scorecard data available.")
        return
    
    # Check match status
    status = scard_data.get("status", "")
    if status:
        st.info(f"**Match Status:** {status}")
    
    # Get scorecard innings list - try both lowercase and camelCase keys
    scorecard = scard_data.get("scorecard", [])
    if not scorecard:
        scorecard = scard_data.get("scoreCard", [])
    
    if not scorecard:
        st.warning("Scorecard data not available for this match yet.")
        return
    
    for innings in scorecard:
        # Get innings details with safe fallbacks
        innings_id = safe_value(innings.get("inningsid", innings.get("inningsId", "")), "")
        bat_team = safe_value(innings.get("batteamname", innings.get("batTeamName", "")), "")
        bat_team_short = safe_value(innings.get("batteamsname", innings.get("batTeamSName", "")), "")
        score = safe_value(innings.get("score", 0), 0)
        wickets = safe_value(innings.get("wickets", 0), 0)
        overs = safe_value(innings.get("overs", 0), 0)
        runrate = safe_value(innings.get("runrate", 0), 0)
        
        # Handle None values for team names - create proper display name
        if bat_team and bat_team != "None":
            team_display = bat_team
        elif bat_team_short and bat_team_short != "None":
            team_display = bat_team_short
        else:
            team_display = f"Team {innings_id}"
        
        st.markdown(f"### 🏏 Innings {innings_id}: {team_display}")
        st.markdown(f"**Score: {score}/{wickets}** in {overs} overs (RR: {runrate})")
        
        # ----- BATTING TABLE -----
        batsmen = innings.get("batsman", innings.get("batsmenData", []))
        
        if batsmen:
            bat_rows = []
            
            if isinstance(batsmen, list):
                for b in batsmen:
                    # Get name with fallbacks
                    name = b.get("name", "") or b.get("batName", "")
                    if not name or name == "None":
                        name = "Unknown"
                    
                    # Get stats with safe values
                    runs = safe_value(b.get("runs"), 0)
                    balls = safe_value(b.get("balls"), 0)
                    fours = safe_value(b.get("fours"), 0)
                    sixes = safe_value(b.get("sixes"), 0)
                    sr = safe_value(b.get("strkrate", b.get("strikeRate", 0)), 0)
                    
                    # Get dismissal and clean it
                    dismissal = b.get("outdec", b.get("outDesc", ""))
                    if not dismissal or dismissal == "None" or dismissal.lower() == "none" or dismissal.strip() == "":
                        if balls > 0:
                            dismissal = "Not Out"
                        else:
                            dismissal = "Yet to Bat"
                    
                    bat_rows.append({
                        "Batsman": name,
                        "R": runs,
                        "B": balls,
                        "4s": fours,
                        "6s": sixes,
                        "SR": sr,
                        "Dismissal": dismissal
                    })
                    
            elif isinstance(batsmen, dict):
                for key, b in batsmen.items():
                    name = b.get("name", "") or b.get("batName", "")
                    if not name or name == "None":
                        continue
                    
                    runs = safe_value(b.get("runs"), 0)
                    balls = safe_value(b.get("balls"), 0)
                    fours = safe_value(b.get("fours"), 0)
                    sixes = safe_value(b.get("sixes"), 0)
                    sr = safe_value(b.get("strkrate", b.get("strikeRate", 0)), 0)
                    
                    dismissal = b.get("outdec", b.get("outDesc", ""))
                    if not dismissal or dismissal == "None" or dismissal.lower() == "none" or dismissal.strip() == "":
                        if balls > 0:
                            dismissal = "Not Out"
                        else:
                            dismissal = "Yet to Bat"
                    
                    bat_rows.append({
                        "Batsman": name,
                        "R": runs,
                        "B": balls,
                        "4s": fours,
                        "6s": sixes,
                        "SR": sr,
                        "Dismissal": dismissal
                    })
            
            if bat_rows:
                st.markdown("**🏏 Batting**")
                df_bat = pd.DataFrame(bat_rows)
                st.dataframe(df_bat, use_container_width=True, hide_index=True)
            else:
                st.caption("No batting data available.")
        
        # ----- BOWLING TABLE -----
        bowlers = innings.get("bowler", innings.get("bowlersData", []))
        
        if bowlers:
            bowl_rows = []
            
            if isinstance(bowlers, list):
                for b in bowlers:
                    name = b.get("name", "") or b.get("bowlName", "")
                    if not name or name == "None":
                        name = "Unknown"
                    
                    overs_b = safe_value(b.get("overs"), 0)
                    maidens = safe_value(b.get("maidens"), 0)
                    runs_b = safe_value(b.get("runs"), 0)
                    wickets_b = safe_value(b.get("wickets"), 0)
                    econ = safe_value(b.get("economy"), 0)
                    
                    bowl_rows.append({
                        "Bowler": name,
                        "O": overs_b,
                        "M": maidens,
                        "R": runs_b,
                        "W": wickets_b,
                        "Econ": econ
                    })
                    
            elif isinstance(bowlers, dict):
                for key, b in bowlers.items():
                    name = b.get("name", "") or b.get("bowlName", "")
                    if not name or name == "None":
                        continue
                    
                    overs_b = safe_value(b.get("overs"), 0)
                    maidens = safe_value(b.get("maidens"), 0)
                    runs_b = safe_value(b.get("runs"), 0)
                    wickets_b = safe_value(b.get("wickets"), 0)
                    econ = safe_value(b.get("economy"), 0)
                    
                    bowl_rows.append({
                        "Bowler": name,
                        "O": overs_b,
                        "M": maidens,
                        "R": runs_b,
                        "W": wickets_b,
                        "Econ": econ
                    })
            
            if bowl_rows:
                st.markdown("**🎯 Bowling**")
                df_bowl = pd.DataFrame(bowl_rows)
                st.dataframe(df_bowl, use_container_width=True, hide_index=True)
            else:
                st.caption("No bowling data available.")
        
        # ----- EXTRAS -----
        extras = innings.get("extras", {})
        if extras:
            extras_total = safe_value(extras.get("total"), 0)
            wides = safe_value(extras.get("wides"), 0)
            noballs = safe_value(extras.get("noballs"), 0)
            legbyes = safe_value(extras.get("legbyes"), 0)
            byes = safe_value(extras.get("byes"), 0)
            st.caption(f"**Extras:** {extras_total} (WD: {wides}, NB: {noballs}, LB: {legbyes}, B: {byes})")
        
        # ----- FALL OF WICKETS (Optional) -----
        fow_data = innings.get("fow", {})
        if fow_data:
            fow_list = fow_data.get("fow", [])
            if fow_list:
                fow_str = " | ".join([
                    f"{safe_value(f.get('runs'), 0)}-{i+1} ({safe_value(f.get('batsmanname', f.get('batsmanName', '')), 'Unknown')}, {safe_value(f.get('overnbr', f.get('overNbr', '')), '')})"
                    for i, f in enumerate(fow_list)
                ])
                st.caption(f"**Fall of Wickets:** {fow_str}")
        
        st.markdown("---")


# ==================== PAGE CONTENT STARTS HERE ====================

st.title("📺 Live / Recent Matches")
st.markdown("---")

# Refresh button
col1, col2 = st.columns([1, 5])
with col1:
    refresh_clicked = st.button("🔄 Refresh", type="primary")

if refresh_clicked:
    st.cache_data.clear()
    st.rerun()

# Fetch matches
with st.spinner("Fetching live/recent matches from Cricbuzz API..."):
    data = fetch_recent_matches()

if data:
    type_matches = data.get("typeMatches", [])
    
    if not type_matches:
        st.info("No live or recent matches found via API at this moment.")
    else:
        # Count total matches for display
        total_matches = 0
        for t in type_matches:
            for s in t.get("seriesMatches", []):
                series_wrapper = s.get("seriesAdWrapper", {})
                if series_wrapper:
                    total_matches += len(series_wrapper.get("matches", []))
        
        st.success(f"✅ Found {total_matches} matches across different formats!")
        
        for t in type_matches:
            match_type = t.get("matchType", "Unknown")
            st.subheader(f"🏏 {match_type} Matches")

            for s in t.get("seriesMatches", []):
                series_wrapper = s.get("seriesAdWrapper", {})
                if not series_wrapper:
                    continue
                    
                series_name = series_wrapper.get("seriesName", "Unknown Series")
                matches = series_wrapper.get("matches", [])

                if not matches:
                    continue

                st.markdown(f"### 📋 {series_name}")

                for m in matches:
                    match_info = m.get("matchInfo", {})
                    match_score = m.get("matchScore", {})

                    match_id = match_info.get("matchId")
                    desc = safe_value(match_info.get("matchDesc"), "N/A")
                    status = safe_value(match_info.get("status"), "N/A")
                    state = safe_value(match_info.get("state"), "")

                    team1_info = match_info.get("team1", {})
                    team2_info = match_info.get("team2", {})
                    team1 = safe_value(team1_info.get("teamSName"), "Team 1")
                    team2 = safe_value(team2_info.get("teamSName"), "Team 2")

                    venue_info = match_info.get("venueInfo", {})
                    venue = safe_value(venue_info.get("ground"), "N/A")
                    city = safe_value(venue_info.get("city"), "")

                    # Parse scores
                    t1_score_str = "—"
                    t2_score_str = "—"

                    if match_score:
                        t1_innings = match_score.get("team1Score", {})
                        t2_innings = match_score.get("team2Score", {})

                        if t1_innings:
                            inn1 = t1_innings.get("inngs1", {})
                            if inn1:
                                runs = safe_value(inn1.get('runs'), 0)
                                wkts = safe_value(inn1.get('wickets'), 0)
                                ovs = safe_value(inn1.get('overs'), "")
                                t1_score_str = f"{runs}/{wkts}"
                                if ovs:
                                    t1_score_str += f" ({ovs})"
                            inn2 = t1_innings.get("inngs2", {})
                            if inn2:
                                runs2 = safe_value(inn2.get('runs'), 0)
                                wkts2 = safe_value(inn2.get('wickets'), 0)
                                t1_score_str += f" & {runs2}/{wkts2}"

                        if t2_innings:
                            inn1 = t2_innings.get("inngs1", {})
                            if inn1:
                                runs = safe_value(inn1.get('runs'), 0)
                                wkts = safe_value(inn1.get('wickets'), 0)
                                ovs = safe_value(inn1.get('overs'), "")
                                t2_score_str = f"{runs}/{wkts}"
                                if ovs:
                                    t2_score_str += f" ({ovs})"
                            inn2 = t2_innings.get("inngs2", {})
                            if inn2:
                                runs2 = safe_value(inn2.get('runs'), 0)
                                wkts2 = safe_value(inn2.get('wickets'), 0)
                                t2_score_str += f" & {runs2}/{wkts2}"

                    # Display match card
                    with st.container(border=True):
                        st.markdown(f"#### {desc} | 📍 {venue}, {city}")
                        
                        c1, c2, c3 = st.columns(3)
                        with c1:
                            st.metric(team1, t1_score_str)
                        with c2:
                            if state == "Complete":
                                st.success(f"**{status}**")
                            elif state == "In Progress":
                                st.warning(f"**🔴 LIVE:** {status}")
                            else:
                                st.info(f"**{status}**")
                        with c3:
                            st.metric(team2, t2_score_str)

                        # Scorecard expander
                        if match_id:
                            with st.expander(f"📊 View Full Scorecard"):
                                with st.spinner("Loading scorecard..."):
                                    scard = fetch_match_scorecard(match_id)
                                    if scard:
                                        display_scorecard(scard)
                                    else:
                                        st.warning("Could not fetch scorecard for this match. It may not be available yet.")
                        
                st.markdown("---")

else:
    st.error("❌ Could not fetch matches from API.")
    st.markdown("### 📋 Demo Data (API Unavailable)")
    
    # Demo data fallback
    demo_matches = [
        {
            "desc": "IRE vs USA - 2nd T20I",
            "status": "Ireland won by 9 runs",
            "team1": "IRE",
            "team2": "USA",
            "t1s": "150/10 (18.5)",
            "t2s": "141/7 (20)"
        },
        {
            "desc": "IND vs AUS - 4th Test, Day 3",
            "status": "Stumps - Australia trail by 120 runs",
            "team1": "IND",
            "team2": "AUS",
            "t1s": "420/8d",
            "t2s": "300/6"
        },
        {
            "desc": "ENG vs NZ - 1st ODI",
            "status": "England won by 5 wickets",
            "team1": "NZ",
            "team2": "ENG",
            "t1s": "242/10 (49.4)",
            "t2s": "245/5 (48.2)"
        },
        {
            "desc": "PAK vs SA - 3rd T20I",
            "status": "Pakistan won by 28 runs",
            "team1": "PAK",
            "team2": "SA",
            "t1s": "185/6 (20)",
            "t2s": "157/9 (20)"
        },
    ]
    
    for match in demo_matches:
        with st.container(border=True):
            st.markdown(f"### 🏏 {match['desc']}")
            c1, c2, c3 = st.columns(3)
            with c1:
                st.metric(match['team1'], match['t1s'])
            with c2:
                st.success(f"**{match['status']}**")
            with c3:
                st.metric(match['team2'], match['t2s'])